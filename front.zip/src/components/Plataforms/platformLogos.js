export const PLATFORM_LOGOS = {
  Netflix:
    'https://res.cloudinary.com/dye4qdrys/image/upload/v1750715177/pilotseries/plataformicons/netflix_b8ku1l.png',
  'HBO Max':
    'https://res.cloudinary.com/dye4qdrys/image/upload/v1750715177/pilotseries/plataformicons/hbo_bnvmhg.png',
  'Amazon Prime Video':
    'https://res.cloudinary.com/dye4qdrys/image/upload/v1750715178/pilotseries/plataformicons/prime_euctcb.png',
  'Disney+':
    'https://res.cloudinary.com/dye4qdrys/image/upload/v1750996152/pilotseries/plataformicons/CH7VJ2UAYJGIRAEMF2VLF5XKBU_tkbaub.avif',
  'Apple TV+':
    'https://res.cloudinary.com/dye4qdrys/image/upload/v1750967305/pilotseries/plataformicons/AppleTVLogo.svg_m4uqs6.png',
  'Paramount+':
    'https://res.cloudinary.com/dye4qdrys/image/upload/v1750966901/pilotseries/plataformicons/apps.14266.9007199266243596.1230f3f2-f93f-4f0e-8de0-9e19b3939e30.3f46be48-a90d-44e5-a76c-9969b7d89625_yyezno.png',
  Starzplay:
    'https://res.cloudinary.com/dye4qdrys/image/upload/v1750966963/pilotseries/plataformicons/channels4_profile_vig0ih.jpg',
  'Movistar+':
    'https://res.cloudinary.com/dye4qdrys/image/upload/v1750962757/pilotseries/plataformicons/movistarplus_wfaotd.jpg'
}
