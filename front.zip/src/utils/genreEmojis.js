export const GENRE_EMOJIS = {
  Drama: '🎭',
  Comedia: '😂',
  Acción: '💥',
  Aventura: '🗺️',
  Crimen: '🚔',
  Animación: '🎨',
  Fantasía: '🧙‍♂️',
  'Ciencia ficción': '👽',
  Romance: '❤️',
  Terror: '👻',
  Suspense: '🔪',
  Misterio: '🕵️‍♂️',
  Musical: '🎤',
  Documental: '🎬'
}
